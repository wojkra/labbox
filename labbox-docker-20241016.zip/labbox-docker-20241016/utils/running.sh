#!/usr/bin/bash
export PYTHONUNBUFFERED=1
export PYTHONWARNINGS=ignore
# Script Vars
RESTORE=FALSE
RESTART_CT=0
# App Vars
SC_ROOT="/opt/sc"

function version { /usr/bin/echo "$@" | /usr/bin/awk -F. '{ printf("%d%03d%03d%03d\n", $1,$2,$3,$4); }'; }

sc_status_check () {
    if [ ! -f "/labbox/labbox_debug" ]; then
      TSC_STATUS=$(/usr/bin/supervisorctl -c /etc/supervisord-tenablesc.conf status TenableSC:* | /usr/bin/grep -c RUNNING)
      TSC_PKG=$(/usr/bin/rpm -q SecurityCenter | /usr/bin/cut -d- -f2)
      SC_VER=$(/opt/sc/support/bin/sqlite3 /opt/sc/application.db "select Value from Configuration where Name is 'Version'")
      if [ $TSC_STATUS -eq 2 ]; then :; 
      else
          /usr/bin/echo "Tenable.sc needs to be restarted."
          /usr/bin/supervisorctl -c /etc/supervisord-tenablesc.conf stop TenableSC:*
          /usr/bin/pkill -9 httpd; /usr/bin/pkill -9 php
          sc_config_enforcement
          /usr/bin/supervisorctl -c /etc/supervisord-tenablesc.conf start TenableSC:*
          ((RESTART_CT=RESTART_CT+1))
          /usr/bin/sleep 2
          TSC_STATUS_CHECK=$(/usr/bin/supervisorctl -c /etc/supervisord-tenablesc.conf status TenableSC:* | /usr/bin/grep -c RUNNING)
          if [ $TSC_STATUS_CHECK -eq 2 ]; then /usr/bin/echo "Tenable.sc is up and running, available at https://127.0.0.1:8443.";
          else
              if [ $RESTART_CT -ge 3 ]; then /usr/bin/echo "Something is wrong. Can not reliably start Tenable.sc. Exiting." exit 1;
              else
                  sc_status_check
              fi
          fi 
      fi
    fi
}

python_lib_update () {
    /usr/bin/echo "Making sure internal components are updated..." 
    if /usr/bin/python3 -m pip install --upgrade pip > /tmp/pip_error_msg 2>&1; then
        /usr/bin/echo "pip is updated."
    else 
        /usr/bin/echo "Something went wrong updating pip..." && cat /tmp/pip_error_msg
    fi
    if /usr/bin/pip3 install --user pytenable --upgrade > /tmp/pytenable_error_msg 2>&1; then
        /usr/bin/echo "pyTenable is updated."
    else 
        /usr/bin/echo "Something went wrong updating pyTenable..." && cat /tmp/pytenable_error_msg
    fi
}

sc_config_enforcement () {
   /usr/bin/echo "Enforcing Labbox Tenable.sc Config..."
   # updated memory limit to support SC-53554
   /usr/bin/sed -i 's/memory_limit = [[:digit:]]\{4\}M/memory_limit = 2300M/' /opt/sc/support/etc/php.ini
   # make sure http can bind to the proper port due to docker privilege
   /usr/sbin/setcap CAP_NET_BIND_SERVICE=+eip /opt/sc/support/bin/httpd
   # making sure logs are properly owned so Apache can start
   /usr/bin/touch /opt/sc/support/logs/access_log
   /usr/bin/chown tns:tns /opt/sc/support/logs/*
   sc_installed_version=$(/opt/sc/support/bin/sqlite3 /opt/sc/application.db "SELECT value FROM Configuration WHERE name = 'Version' AND type = 64")
   # Docker 4.23 bug SEG-14252
   /usr/bin/chmod 777 /tmp
   # Version Specific Configs
   # Greater than 6.0
   if [ $(version $sc_installed_version) -ge $(version "6.0.0") ]; then
    	# VRB-1657369
			/usr/bin/sed -i '/AddType application\/x-httpd-php .php/a AddType application/manifest+json .webmanifest' $SC_ROOT/support/conf/module.conf
      # SC-53323 - Serve chunks as Gzip encoded component
			/usr/bin/grep -qF 'Header set content-encoding gzip' $SC_ROOT/support/conf/headers.conf || 
        /usr/bin/echo -e '\n<FilesMatch "\.(js|css)$">\n\tHeader set content-encoding 'gzip'\n</FilesMatch>' >> $SC_ROOT/support/conf/headers.conf
      /usr/bin/grep -qF 'Header unset content-encoding' $SC_ROOT/support/conf/headers.conf || 
        /usr/bin/echo -e '\n<FilesMatch "(telemetry.js|nessus6.js|nesgeturl.js)$">\n\tHeader unset content-encoding\n</FilesMatch>' >> $SC_ROOT/support/conf/headers.conf
      # SC-52441
      /usr/bin/sed -i 's:PidFile "logs/httpd.pid":PidFile "/opt/sc/support/logs/httpd.pid":g' /opt/sc/support/conf/mpm.conf
      /usr/bin/sed -i 's:= new_oids:= new_oids\n\nconfig_diagnostics = 1\nopenssl_conf = openssl_init\n\n.include /opt/sc/data/fips.cnf\n\n[openssl_init]\nproviders = provider_sect\nalg_section = algorithm_sect\n\n[provider_sect]\nfips = fips_sect\ndefault = default_sect\n\n[default_sect]\nactivate = 1\n\n[algorithm_sect]\ndefault_properties = fips=yes:g' /opt/sc/data/openssl.cnf
      # headers.conf SC-52746 SC-53720
			/usr/bin/sed -i 's/.*Content-Security-Policy.*/Header always set Content-Security-Policy "frame-ancestors '"'"'self'"'"' app.pendo.io"/'  /opt/sc/support/conf/headers.conf
			/usr/bin/sed -i 's:Include conf/scannerproxy.conf:Include conf/scannerproxy.conf\n\nRewriteCond %{REQUEST_URI} ^/tsc/\nRewriteRule ^ /index_tsc.php [L]\n\nRewriteCond %{REQUEST_URI} ^/\nRewriteRule ^/$ /index.php [L]:g'  /opt/sc/support/conf/rewrite.conf
      # Make sure apache is happy on 6.1+ on M# Processors
      if [[ $(grep "Mutex posixsem" /opt/sc/support/conf/ssl.conf -c) != 1 ]]; then
          /usr/bin/echo "Mutex posixsem" >> /opt/sc/support/conf/ssl.conf
      fi
   fi
}

sc_backup () {
  if [ -f "/labbox/disable_backup" ]; then
    /usr/bin/echo "Backups are explictly disabled per 'disable_backup', continuing."
  else
    /usr/bin/echo "Backing up Labbox data and config."
    /usr/bin/supervisorctl -c /etc/supervisord-tenablesc.conf stop TenableSC:*
    /usr/bin/mkdir /labbox/backups > /dev/null 2>&1
    FILE_DATE=$(/usr/bin/date +"%Y-%m-%d-%H%M")
    SC_VER=$(/opt/sc/support/bin/sqlite3 /opt/sc/application.db "select Value from Configuration where Name is 'Version'")
    /usr/bin/tar -pzcf /labbox/backups/sc-backup_"$SC_VER"_"$FILE_DATE".tar.gz /opt/sc > /dev/null 2>&1
    /usr/bin/supervisorctl -c /etc/supervisord-tenablesc.conf start TenableSC:*
    /usr/bin/echo "Created a Labbox backup in the backups folder"
  fi
}


labbox_reset () {
    /usr/bin/echo "Resetting Labbox to a clean state."
    /usr/bin/rm -f /reset
    /usr/bin/supervisorctl -c /etc/supervisord-tenablesc.conf stop TenableSC:*
    /usr/bin/kill $(cat /var/run/supervisord.pid)
    /usr/bin/pkill -u tns
    /usr/bin/dnf -y remove SecurityCenter*
    /usr/bin/rm -rf /opt/sc /etc/labbox.json
}

labbox_setup () {
   /usr/bin/echo "Installing new Tenable.sc console..."
   # Docker 4.23 bug SEG-14252
   /usr/bin/chmod 777 /tmp
   if /usr/bin/dnf info SecurityCenter --refresh | /usr/bin/grep 'Available Packages' > /dev/null 2>&1 ; then
       /usr/bin/rpm -ivh --nodeps $(/usr/bin/repoquery --location --latest-limit=1 SecurityCenter)
   fi
   /usr/bin/su tns -c 'export LD_LIBRARY_PATH=/opt/sc/support/lib; /opt/sc/support/bin/php /opt/sc/src/tools/installSSLCertificate.php -q'
   /usr/bin/echo "Starting Tenable.sc services..."
   # pre-checks and any required upstream changes
   sc_config_enforcement
   /usr/bin/supervisord -n -c /etc/supervisord-tenablesc.conf &
   /usr/bin/sleep 5
   /usr/bin/touch /update-all
}

#if we detect a request to do a restore on container start, do that first.
sc_restore=/labbox/tsc_restore
sc_backup=$(compgen -G "/labbox/backups/sc-backup_*.tar.gz" | head -n 1)
sc_backup_version=$(echo $sc_backup | cut -d'_' -f 2)
if [ -f "$sc_restore" ]; then
   if [ ! -f "$sc_backup" ]; then
       /usr/bin/echo "Restore requested, but no backup file found.  Removing restoration request (tsc_restore) and continuing normal start."
       /usr/bin/rm -f /labbox/tsc_restore
   else
       /usr/bin/echo "----------------------------"
       /usr/bin/echo "Restore requested..."
       /usr/bin/echo "----------------------------"
       SC_RPM=$(compgen -G /labbox/setup/SecurityCenter-$sc_backup_version-*.rpm)
       SC_INSTALL=$(/opt/sc/support/bin/sqlite3 /opt/sc/application.db "select Value from Configuration where Name is 'Version'" 2>&1)
       if [ ! -f "$SC_RPM" ]; then
          /usr/bin/echo "Downloading Tenable.sc $sc_backup_version"
          /usr/bin/dnf download SecurityCenter-$sc_backup_version --destdir /labbox/setup > /dev/null 2>&1
          SC_RPM=$(compgen -G /labbox/setup/SecurityCenter-$sc_backup_version-*.rpm | head -n 1)
       fi
       if [ "$SC_INSTALL" != "$sc_backup_version" ]; then
          /usr/bin/echo "$SC_INSTALL doesn't match $sc_backup_version"
          /usr/bin/echo "Ensuring correct Tenable.sc version is installed ($sc_backup_version)"
          /usr/bin/dnf -y erase SecurityCenter
          /usr/bin/rm -rf /opt/sc
          /usr/bin/rpm -ivh --force --nodeps "$SC_RPM"
          /usr/bin/sleep 20
          /usr/bin/pkill -9 httpd; /usr/bin/pkill -9 php
       fi
       /usr/bin/echo "Restoring Backup..."
       /usr/bin/tar -xf $sc_backup -C /
       /usr/bin/echo "Finalizing Restore..."
       sc_config_enforcement
       /usr/bin/supervisord -n -c /etc/supervisord-tenablesc.conf &
       /usr/bin/labbox boxify
       /usr/bin/rm -f /labbox/tsc_restore
       /usr/bin/rm -f /etc/labbox.json
       sc_status_check
       DATE=$(/usr/bin/date)
       /usr/bin/echo "Tenable.sc has been restored at $DATE from the file at $sc_backup"
       /usr/bin/echo ""
       RESTORE=TRUE
   fi
fi

# run gapfill on boot if SC is already installed (assumes setup), if not, install sc
sc_install=/opt/sc/application.db
sc_active=/labbox/tsc_active_plugin_update
sc_feed=/labbox/tsc_sc_feed_update
if [ -f "$sc_install" ] && [ "$RESTORE" != "TRUE" ]; then
   SC_VER=$(/opt/sc/support/bin/sqlite3 /opt/sc/application.db "select Value from Configuration where Name is 'Version'")
   /usr/bin/echo "Tenable.sc $SC_VER Installed"
   # pre-checks and any required upstream changes
   sc_config_enforcement
   # start Tenable.sc cause docker something something and give it time to come up
   /usr/bin/echo "Starting Tenable.sc Services..."
   /usr/bin/rm -f /opt/sc/daemons/jobd.pid /opt/sc/support/logs/httpd.pid
   /usr/bin/supervisord -n -c /etc/supervisord-tenablesc.conf &
   /usr/bin/sleep 5
   # Making sure internal components are updated.
   python_lib_update
   /usr/bin/echo "Looking for any Dashboard gaps and fixing them..." 
   /usr/bin/labbox gapfill
   if [ -f "$sc_active" ]; then
       /usr/bin/labbox feed_update active
   fi
   if [ -f "$sc_feed" ]; then
       /usr/bin/labbox feed_update sc
   fi
   DATE=$(/usr/bin/date)
   /usr/bin/echo "Docker Labbox started at $DATE."
   sc_status_check
   /usr/bin/echo ""
elif [ "$RESTORE" != "TRUE" ]; then
   # Runs on new builds only
   labbox_setup
fi

while sleep 60; do
  sc_status_check
  if [ -e /update-all ] ; then
    /usr/bin/echo "Starting a complete rebuild process..."
    # Making sure internal components are updated.
    python_lib_update
    /usr/bin/rm -f /update-all
    /usr/bin/echo "Syncing all of Labbox..."
    /usr/bin/labbox sync full
    sc_config_enforcement
    /usr/bin/echo "Finished rebuild."
    /usr/bin/echo "Looking for any Dashboard gaps and fixing them..." 
    /usr/bin/labbox gapfill
    DATE=$(/usr/bin/date)
    /usr/bin/echo "Completed rebuild process at $DATE."
    sc_status_check
    /usr/bin/echo ""
  fi

  if [ -e /update-repos ] ; then
    /usr/bin/echo "Syncing repos only..."
    # Making sure internal components are updated.
    python_lib_update
    /usr/bin/rm -f /update-repos
    /usr/bin/echo "Syncing Labbox..."
    /usr/bin/labbox sync repos
    sc_config_enforcement
    /usr/bin/echo "Finished repo sync."
    /usr/bin/echo "Requesting Feed and Plugin updates, since we just updated vulnerability data..."
    /usr/bin/labbox feed_update active
    /usr/bin/labbox feed_update sc
    /usr/bin/echo "Looking for any Dashboard gaps and fixing them..." 
    /usr/bin/labbox gapfill
    DATE=$(/usr/bin/date)
    /usr/bin/echo "Completed repo sync at $DATE."
    sc_status_check
    /usr/bin/echo ""
  fi

  if [ -e /gapfill ] ; then
    /usr/bin/echo "Looking for any Dashboard gaps and fixing them..." 
    /usr/bin/rm -f /gapfill
    /usr/bin/labbox gapfill
    DATE=$(/usr/bin/date)
    /usr/bin/echo "Completed gapfill at $DATE."
    sc_status_check
    /usr/bin/echo ""
  fi

  if [ -e /reset ] ; then
    labbox_reset
    labbox_setup
  fi

  if [ -e /tsc_backup ] ; then
    /usr/bin/echo "Backing up Tenable.sc..." 
    /usr/bin/rm -f /tsc_backup
    sc_backup
    DATE=$(/usr/bin/date)
    /usr/bin/echo "Completed backup at at $DATE."
    sc_status_check
    /usr/bin/echo ""
  fi
  
  if [ -e /boxify ] ; then
    /usr/bin/echo "Fixing permissions and resetting user passwords..." 
    /usr/bin/rm -f /boxify
    /usr/bin/labbox boxify
    DATE=$(/usr/bin/date)
    /usr/bin/echo "Completed boxify at at $DATE."
    sc_status_check
    /usr/bin/echo ""
  fi

  if [ -e /license_update ] ; then
    /usr/bin/echo "Applying new Tenable.sc license..."
    /usr/bin/rm -f /license_update
    /usr/bin/labbox license_update
    DATE=$(/usr/bin/date)
    /usr/bin/echo "Completed Tenable.sc license update at at $DATE."
    sc_status_check
    /usr/bin/echo ""
  fi

  if [ -e /ea_testing ] ; then
    SC_EA_RPM=$(compgen -G "/labbox/ea/SecurityCenter*.rpm" | head -n 1)
    if [ ! -f "$SC_EA_RPM" ]; then
       /usr/bin/echo "EA testing requested, but no EA install found.  Removing testing request (ea_testing) and continuing operations."
       /usr/bin/echo ""
       /usr/bin/rm -f /ea_testing
    else
      /usr/bin/echo "Setting up Labbox for EA testing..."
      /usr/bin/rm -f /ea_testing
      sc_backup
      /usr/bin/supervisorctl -c /etc/supervisord-tenablesc.conf stop TenableSC: ; /usr/bin/pkill -9 httpd; /usr/bin/pkill -9 php*
      /usr/bin/rpm -Uvh --nodeps "$SC_EA_RPM"
      /usr/bin/pkill -9 httpd; /usr/bin/pkill -9 php
      sc_config_enforcement
      sc_status_check
      DATE=$(/usr/bin/date)
      /usr/bin/echo "Completed Labbox EA update at at $DATE."
      /usr/bin/echo ""
    fi
  fi

  if [ -e /tsc_upgrade ] ; then
    /usr/bin/echo "Checking for GA updates to Tenable.sc..."
    /usr/bin/dnf makecache
    if /usr/bin/dnf info SecurityCenter | /usr/bin/grep 'Available Packages' > /dev/null 2>&1 ; then
       sc_backup
       /usr/bin/supervisorctl -c /etc/supervisord-tenablesc.conf stop TenableSC:* ; /usr/bin/pkill -9 httpd; /usr/bin/pkill -9 php
       /usr/bin/rpm -Uvh --nodeps $(repoquery --location SecurityCenter)
       /usr/bin/pkill -9 httpd; /usr/bin/pkill -9 php
       sc_config_enforcement
       sc_status_check
       DATE=$(/usr/bin/date)
       /usr/bin/echo "Completed Tenable.sc update at at $DATE."
    else
       /usr/bin/echo "No GA updates to Tenable.sc available or cannot check Tenable's servers."
       /usr/bin/echo "Removing Tenable.sc upgrade request (tsc_upgrade) and continuing operations."
    fi
    /usr/bin/rm -f /tsc_upgrade
    /usr/bin/echo ""
  fi
  
  if [ -e /tsc_upgrade_forced ] ; then
    /usr/bin/echo "Forced GA updates to Tenable.sc..."
    /usr/bin/yum makecache fast
    sc_backup
    /usr/bin/supervisorctl -c /etc/supervisord-tenablesc.conf stop TenableSC:* ; /usr/bin/pkill -9 httpd; /usr/bin/pkill -9 php
    /usr/bin/rpm -Uvh --nodeps --force $(repoquery --location SecurityCenter)
    /usr/bin/pkill -9 httpd; /usr/bin/pkill -9 php
    sc_config_enforcement
    sc_status_check
    DATE=$(/usr/bin/date)
    /usr/bin/echo "Completed forced Tenable.sc update at at $DATE."
    /usr/bin/rm -f /tsc_upgrade
    /usr/bin/echo ""
  fi

  if [ -e /pause ] ; then
     /usr/bin/echo "Pausing operations..."
     while sleep 10; do
        if [ ! -e /pause ] ; then
           /usr/bin/echo "Resuming operations..."
           break
        else
           /usr/bin/echo "Still paused."
        fi
     done
  fi

  if [ -e /tsc_testing ] ; then
    SC_TESTING_RPM=$(compgen -G "/labbox/setup/SecurityCenter*.rpm" | head -n 1)
    if [ ! -f "$SC_TESTING_RPM" ]; then
       /usr/bin/echo "Testing Build requested, but no testing installer found.  Removing testing request (tsc_testing) and continuing operations."
       /usr/bin/echo ""
       /usr/bin/rm -f /tsc_testing
    else
      /usr/bin/echo "Setting up Labbox for testing..."
      /usr/bin/rm -f /tsc_testing
      sc_backup
      labbox_reset
      /usr/bin/rpm -ivh --nodeps "$SC_TESTING_RPM"
      /usr/bin/pkill -9 httpd; /usr/bin/pkill -9 php
      /usr/bin/su tns -c 'export LD_LIBRARY_PATH=/opt/sc/support/lib; /opt/sc/support/bin/php /opt/sc/src/tools/installSSLCertificate.php -q'
      sc_config_enforcement
      /usr/bin/supervisord -n -c /etc/supervisord-tenablesc.conf &
      /usr/bin/sleep 5
      /usr/bin/supervisorctl -c /etc/supervisord-tenablesc.conf start TenableSC:*
      sc_status_check
      /usr/bin/python3 /labbox/sc_provision.py
      sc_status_check
      /usr/bin/labbox config_update tsc
      DATE=$(/usr/bin/date)
      /usr/bin/echo "Completed Labbox Testing setup at at $DATE."
      /usr/bin/echo ""
    fi
  fi

done
