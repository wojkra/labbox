#!/usr/bin/bash

YUMUPDATE=0

# Note running container version
/usr/bin/echo "Container files at 20241016"

# install a new version of labbox, if detected.
/usr/bin/dos2unix -q /labbox/labbox.py
/usr/bin/diff /labbox/labbox.py /usr/bin/labbox > /dev/null 2>&1
if [ $? -eq 0 ]; then /usr/bin/echo "No updates to labbox.py detected."; 
else 
   LABBOX_HASH=$(/usr/bin/md5sum /labbox/labbox.py)
   /usr/bin/cp -f /labbox/labbox.py /usr/bin/labbox
   /usr/bin/chmod +x /usr/bin/labbox
   /usr/bin/echo "Updated the Labbox Binary with $LABBOX_HASH" 
fi

# install a new version of repos & repo keys, if detected
/usr/bin/dos2unix -q /labbox/Tenable.repo
/usr/bin/diff /labbox/Tenable.repo /etc/yum.repos.d/Tenable.repo > /dev/null 2>&1
if [ $? -eq 0 ]; then /usr/bin/echo "No updates to Tenable.repo detected."; 
else
   REPO_HASH=$(/usr/bin/md5sum /labbox/Tenable.repo) 
   /usr/bin/cp -f /labbox/Tenable.repo /etc/yum.repos.d/Tenable.repo;
   /usr/bin/echo "Updated the Tenable Repo with $REPO_HASH";
   YUMUPDATE=1 
fi

/usr/bin/dos2unix -q /labbox/RPM-GPG-KEY-Tenable 
/usr/bin/diff /labbox/RPM-GPG-KEY-Tenable /etc/pki/rpm-gpg/RPM-GPG-KEY-Tenable > /dev/null 2>&1
if [ $? -eq 0 ]; then /usr/bin/echo "No updates to repo key detected."; 
else
   KEY_HASH=$(/usr/bin/md5sum /labbox/RPM-GPG-KEY-Tenable)  
   /usr/bin/cp -f /labbox/RPM-GPG-KEY-Tenable /etc/pki/rpm-gpg/RPM-GPG-KEY-Tenable;
   /usr/bin/echo "Updated the Tenable Repo Key with $KEY_HASH";
   YUMUPDATE=1 
fi

# install a new tenable.sc license, if needed
/usr/bin/dos2unix -q /labbox/license.key
/usr/bin/diff /labbox/license.key /opt/sc/daemons/license.key > /dev/null 2>&1
if [ $? -eq 0 ]; then /usr/bin/echo "No updates to Tenable.sc license detected."; 
else
   LICENSE_HASH=$(/usr/bin/md5sum /labbox/license.key)  
   /usr/bin/mkdir -p /opt/sc/daemons/
   if [ -f /opt/sc/daemons/license.key ]; then /usr/bin/touch /license_update; fi
   /usr/bin/cp -f /labbox/license.key /opt/sc/daemons/license.key
   /usr/bin/echo "Updated the Tenable.sc license with $LICENSE_HASH and told Tenable.sc a new license exists.";
fi

# install a new supervisord conf, if needed
/usr/bin/dos2unix -q /labbox/supervisord.conf
/usr/bin/diff /labbox/supervisord.conf /etc/supervisord-tenablesc.conf > /dev/null 2>&1
if [ $? -eq 0 ]; then /usr/bin/echo "No updates to supervisor conf detected."; 
else
   LICENSE_HASH=$(/usr/bin/md5sum /labbox/supervisord.conf)  
   /usr/bin/cp -f /labbox/supervisord.conf /etc/supervisord-tenablesc.conf;
   /usr/bin/echo "Updated the supervisord conf with $LICENSE_HASH";
fi

# install a new running conf, if needed
/usr/bin/dos2unix -q /labbox/running.sh
/usr/bin/diff /labbox/running.sh /running.sh > /dev/null 2>&1
if [ $? -eq 0 ]; then /usr/bin/echo "No updates to running config detected."; 
else
   RUNNING_HASH=$(/usr/bin/md5sum /labbox/running.sh)  
   /usr/bin/cp -f /labbox/running.sh /running.sh;
   /usr/bin/echo "Updated the running conf with $RUNNING_HASH";
fi

if [ $YUMUPDATE -eq 1 ]; then /usr/bin/echo "Change to repo config, re-making cache."; /usr/bin/dnf makecache; fi
