#!/bin/bash

# Pre-Debug Tests
# Are we in the right directory?
if [ ! -d "utils" ] || [ ! -f "Dockerfile" ]
then
    echo "Please run this command from your labbox-docker folder."
    echo "You're in $(pwd) now"
    exit 1
fi

# Is Docker Installed?
if [ ! -d "/Applications/Docker.app" ]
then
    echo "Ensure Docker is installed; please install Docker and try again."
    exit 1
fi


# Is Docker Running?
if ! ps aux | grep -v grep | grep -c "docker" > /dev/null
then
    echo "Docker isn't running. Please start Docker and try again"
    exit 1
fi

TENB_USER=$(whoami)
DEBUG_DATE=$(date +%Y%m%d%I%M)
LABBOX_DEBUG_FOLDER="labbox-debug-$TENB_USER-$DEBUG_DATE"
LABBOX_DEBUG_FILE="labbox_debug_$TENB_USER-$DEBUG_DATE.zip"
CURRENT_WD=$(pwd)

mkdir /tmp/$LABBOX_DEBUG_FOLDER

# Generate file hashes to labbox_files_md5.txt
find . -type f -exec md5 {} > /tmp/$LABBOX_DEBUG_FOLDER/files_md5.txt \;

# Gather data and create the main file
echo "~~~~~~~~~~~~~~~~~~~~~~~~" > /tmp/$LABBOX_DEBUG_FOLDER/debug_summary.txt
echo "Labbox Debug" > /tmp/$LABBOX_DEBUG_FOLDER/debug_summary.txt
echo "Debug Gathered: $(date)" >> /tmp/$LABBOX_DEBUG_FOLDER/debug_summary.txt 
echo "~~~~~~~~~~~~~~~~~~~~~~~~" >> /tmp/$LABBOX_DEBUG_FOLDER/debug_summary.txt
echo "" >> /tmp/$LABBOX_DEBUG_FOLDER/debug_summary.txt
echo "~~~~~~~~~~~~~" >> /tmp/$LABBOX_DEBUG_FOLDER/debug_summary.txt
echo "Labbox Version & Location:" >> /tmp/$LABBOX_DEBUG_FOLDER/debug_summary.txt
echo "~~~~~~~~~~~~~" >> /tmp/$LABBOX_DEBUG_FOLDER/debug_summary.txt
echo "$(egrep -wo 'Image v[0-9,\.]{1,6}' ./utils/start.sh 2>&1)" >> /tmp/$LABBOX_DEBUG_FOLDER/debug_summary.txt 
echo "$(egrep -wo 'Container files at 20[0-9]{1,6}' ./utils/update.sh 2>&1)" >> /tmp/$LABBOX_DEBUG_FOLDER/debug_summary.txt
LABBOX_PATH="$(cd "$(dirname "$1")"; pwd -P)/$(basename "$1")" 
echo "Labbox Files at $LABBOX_PATH" >> /tmp/$LABBOX_DEBUG_FOLDER/debug_summary.txt
echo "" >> /tmp/$LABBOX_DEBUG_FOLDER/debug_summary.txt
echo "~~~~~~~~~~~~~" >> /tmp/$LABBOX_DEBUG_FOLDER/debug_summary.txt
echo "Labbox Containers On System:" >> /tmp/$LABBOX_DEBUG_FOLDER/debug_summary.txt
echo "~~~~~~~~~~~~~" >> /tmp/$LABBOX_DEBUG_FOLDER/debug_summary.txt
LABBOX_CONTAINER_LIST=$(docker ps -a --filter="name=tenablesc" --format "table {{.ID}}\t{{.Image}}\t{{.Names}}\t{{.Status}}")
echo "$LABBOX_CONTAINER_LIST" >> /tmp/$LABBOX_DEBUG_FOLDER/debug_summary.txt
echo "" >> /tmp/$LABBOX_DEBUG_FOLDER/debug_summary.txt

echo "~~~~~~~~~~~~~" >> /tmp/$LABBOX_DEBUG_FOLDER/debug_summary.txt
echo "System Information:" >> /tmp/$LABBOX_DEBUG_FOLDER/debug_summary.txt
echo "~~~~~~~~~~~~~" >> /tmp/$LABBOX_DEBUG_FOLDER/debug_summary.txt
echo "$(system_profiler SPHardwareDataType SPSoftwareDataType)" >> /tmp/$LABBOX_DEBUG_FOLDER/debug_summary.txt
echo "$(system_profiler SPApplicationsDataType | grep -B 1 -A 8 'Docker:')" >> /tmp/$LABBOX_DEBUG_FOLDER/debug_summary.txt
echo "" >> /tmp/$LABBOX_DEBUG_FOLDER/debug_summary.txt

echo "~~~~~~~~~~~~~" > /tmp/$LABBOX_DEBUG_FOLDER/docker_prefs.txt
echo "Docker Preferences:" >> /tmp/$LABBOX_DEBUG_FOLDER/docker_prefs.txt
echo "~~~~~~~~~~~~~" >> /tmp/$LABBOX_DEBUG_FOLDER/docker_prefs.txt
echo "$(cat ~/Library/Group\ Containers/group.com.docker/settings.json 2>&1)" >> /tmp/$LABBOX_DEBUG_FOLDER/docker_prefs.txt

LABBOX_CONTAINERS=$(docker ps -a --filter="name=tenablesc" --format "{{.Image}} {{.Names}} {{.ID}}")
while IFS= read -r line; do
    CONTAINER_IMAGE=$(echo "$line" | awk -F' ' '{ print $1}')
    CONTAINER_NAME=$(echo "$line" | awk -F' ' '{ print $2}')
    CONTAINER_ID=$(echo "$line" | awk -F' ' '{ print $3}')

    echo "~~~~~~~" > /tmp/$LABBOX_DEBUG_FOLDER/$CONTAINER_NAME-Inspect.txt
    echo "Container Inspect Details: $CONTAINER_NAME" >> /tmp/$LABBOX_DEBUG_FOLDER/$CONTAINER_NAME-Inspect.txt 
    echo "~~~~~~~" >> /tmp/$LABBOX_DEBUG_FOLDER/$CONTAINER_NAME-Inspect.txt 
    echo "$(docker inspect $CONTAINER_ID  2>&1)" >> /tmp/$LABBOX_DEBUG_FOLDER/$CONTAINER_NAME-Inspect.txt 
    echo "" >> /tmp/$LABBOX_DEBUG_FOLDER/$CONTAINER_NAME-Inspect.txt

    docker cp -q $CONTAINER_NAME:/etc/labbox.json /tmp/$LABBOX_DEBUG_FOLDER/$CONTAINER_NAME-sc_sync_status.json

    echo "~~~~~~~" > /tmp/$LABBOX_DEBUG_FOLDER/$CONTAINER_IMAGE-Image_Build.txt
    echo "$CONTAINER_IMAGE Image Build Details:" >> /tmp/$LABBOX_DEBUG_FOLDER/$CONTAINER_IMAGE-Image_Build.txt
    echo "~~~~~~~" >> /tmp/$LABBOX_DEBUG_FOLDER/$CONTAINER_IMAGE-Image_Build.txt
    echo "$(docker image history --no-trunc $CONTAINER_IMAGE  2>&1)" >> /tmp/$LABBOX_DEBUG_FOLDER/$CONTAINER_IMAGE-Image_Build.txt
    echo "" >> /tmp/$LABBOX_DEBUG_FOLDER/$CONTAINER_IMAGE_Image_Build.txt

    echo "~~~~~~~" > /tmp/$LABBOX_DEBUG_FOLDER/$CONTAINER_IMAGE-Logs.txt
    echo "$CONTAINER_NAME Container Logs:" >> /tmp/$LABBOX_DEBUG_FOLDER/$CONTAINER_IMAGE-Logs.txt
    echo "~~~~~~~" >> /tmp/$LABBOX_DEBUG_FOLDER/$CONTAINER_IMAGE-Logs.txt 
    echo "$(docker logs $CONTAINER_NAME 2>&1)" >> /tmp/$LABBOX_DEBUG_FOLDER/$CONTAINER_IMAGE-Logs.txt
    echo "" >> /tmp/$LABBOX_DEBUG_FOLDER/$CONTAINER_IMAGE-Logs.txt
done <<< "$LABBOX_CONTAINERS"

# Generate the debug file
(cd /tmp ; zip -q $LABBOX_DEBUG_FILE $LABBOX_DEBUG_FOLDER/*)
mv /tmp/$LABBOX_DEBUG_FILE $CURRENT_WD && cd $CURRENT_WD
echo "Debug $LABBOX_DEBUG_FILE created at $(pwd)"
echo "Send this file to the Tenable Demo Team for troubleshooting."
rm -r /tmp/$LABBOX_DEBUG_FOLDER/