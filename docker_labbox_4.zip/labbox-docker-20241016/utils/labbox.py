#!/usr/bin/python3
import re, os, sys, datetime, shutil, requests, getopt, \
        zipfile, json, gnupg, hashlib, tarfile
from cmd import Cmd
from base64 import b64decode
from time import sleep, time
from io import StringIO
from random import randint
from time import sleep
from subprocess import getoutput as run
from distutils.version import LooseVersion
from socket import socket, AF_INET, SOCK_DGRAM
from tenable.sc import TenableSC

class CommandLine(Cmd):
    def __init__(self):
        Cmd.__init__(self)
        self.load_configfile()

    def help_help(self):
        pass

    def load_configfile(self, filename='/etc/labbox.json'):
        '''
        Loads/reloads the config file.
        '''
        if not os.path.exists(filename):
            # if there is no configfile yet, then we will load the
            # default values into the config variable.
            self.config = {
                # "This is the Labbox Encryption Key!"
                'enc_key': 'VGhpcyBpcyB0aGUgTGFiYm94IEVuY3J5cHRpb24gS2V5IQ==',
                'dataset': 'demo',
                'version': 0,
                'updated': {
                    'sc-data': 0,
                    'sc-repos': 0,
                    'tsc-config': 0,
                },
            }
        else:
            with open(filename) as fobj:
                # open the configfile and store the information into
                # the config variable.
                self.config = json.load(fobj)

    def save_configfile(self, filename='/etc/labbox.json'):
        '''
        Saves the configfile to disk.
        '''
        with open(filename, 'w') as fobj:
            json.dump(self.config, fobj)

    def get_download_link(self, file_name):
        '''
        Grab the correct download link from Tenable Downloads
        '''
        download_root = "https://www.tenable.com/downloads/api/v1/public/pages/demo-data/downloads/"
        user_agreement = "?i_agree_to_tenable_license_agreement=true"
        url = "https://www.tenable.com/downloads/api/v1/public/pages/demo-data"
        download_headers = {"Accept": "application/json"}
        response = requests.request("GET", url, headers=download_headers)
        demo_files = response.json()['downloads']
        download_url = ""
        for file_available in demo_files:
            if file_available['file'] == file_name:
                download_url = download_root + str(file_available['id']) + "/download" + user_agreement
        return download_url

    def getfile(self, url, filename):
        '''
        A simple downloader for large files
        '''
        resp = requests.get(url, stream=True) 
        # If something is wrong with the download, stop.
        if resp.status_code != 200:
            print('Something is wrong; bad response trying to download files.')
            exit()
        # Write data as we go so we don't take up massive amounts of RAM.
        with open(filename, 'wb') as fobj:
            for chunk in resp.iter_content(chunk_size=1024):
                if chunk:
                    fobj.write(chunk)

    def download(self, package):
        '''
        Downloads the appropriate package to disk
        '''

        # compute the number of days that have elapsed since the last update
        try:
            days = (int(time()) - self.config['updated'][package]) / 86400
        except KeyError:
            days = 0

        # based on the number of days, lets go ahead and figure out which
        # delta we need.
        if days <= 1:
            delta = 'daily'
        elif days <= 7:
            delta = 'weekly'
        elif days <= 30:
            delta = 'monthly'
        else:
            delta = 'all'

        if self.config['dataset'] != 'research' and package != 'tsc-config':
            dl_filename = '%s-%s-%s.tar.gz.enc' % (self.config['dataset'], package, delta)
        elif package == 'tsc-config':
            dl_filename = 'tsc-config.tar.gz.enc'
        else:
            dl_filename = '%s-%s.tar.gz.enc' % (package, delta)

        print('\t- Downloading %s...' % dl_filename)
        tries = 0
        complete = False
        while tries <= 5 and not complete:
            try:
                self.getfile(self.get_download_link(dl_filename),
                             '/tmp/%s.tar.gz.enc' % package)
                complete = True
            except requests.exceptions.ChunkedEncodingError:
                print('!!! Connection was reset.  Attempting to download again...')
                tries += 1
        if tries > 5 and not complete:
            print('!!! Could not download the file after multiple attempts.  Aborting.')
            exit()

    def unpack(self, package):
        '''
        Unpacks the package specified
        '''
        encpkgfile = '/tmp/%s.tar.gz.enc' % package
        tarpkgfile = '/tmp/%s.tar.gz' % package
        gpg = gnupg.GPG(gpgbinary='/usr/bin/gpg')

        # decrypt the package.
        print('\t- Decrypting Package...')
        with open(encpkgfile, 'rb') as encobj:
            status = gpg.decrypt_file(encobj, 
                passphrase=b64decode(self.config['enc_key']).decode('utf-8'),
                output=tarpkgfile)

        # if we were able to decrypt the package, then lets inform the user
        # and continue, if decryption failed, then lets throw an error and bail.
        if status.ok:
            print('\t- Decryption Successful, Package OK')
        else:
            print('ERROR: Could not decrypt package')
            exit()

        # as decryption is successful, we will now delete the encrypted file.
        os.remove(encpkgfile)
        
        # now to unpack the now decrypted volume
        print('\t- Unpacking Package...')
        try:
            tar = tarfile.open(tarpkgfile)
            tar.extractall(path='/')
        except:
            print('ERROR: Could not unpack package, something bad happened. Try again.')
            exit()
        print('\t- Package unpacked onto filesystem.')
        os.remove(tarpkgfile)
        print('\t- Package file removed.')

    def overlay(self, package):
        '''
        Convenience function to download & unpack a given package.  Here we will
        Also update the "last updated" value stored in the configuration.
        '''
        print('Attempting to download and overlay %s package...' % package)
        self.download(package)
        self.unpack(package)
        self.config['updated'][package] = int(time())
        self.save_configfile()

            

    def do_sync(self, stype):
        '''
        Sync will synchronize and then modify the newly synced data for use as a
        local off-line installation.  The sync type must be specified as part
        of the command.

        full, sc, all           Synchronize everything (config & repos).
        repos                   Sync the SecurityCenter repository data only.
        '''

        # if the user didnt specify anything, then we should inform them of the
        # options that they can use and bail.
        if stype == '':
            self.do_help('sync')
            return

        if run('/usr/bin/rpm -qa SecurityCenter') == '':
            sys.exit('!!! Tenable.sc not installed.  Aborting Sync...           !!!')
        else:
            print('Checking & applying if necessary any Tenable.sc updates...   ')
            run('/usr/bin/yum clean all')
            if run('/usr/bin/yum info SecurityCenter | /usr/bin/grep "Available Packages"'):
                print('Downloading and updating Tenable.sc to the latest version...  ')
                run('/usr/bin/supervisorctl -c /etc/supervisord-tenablesc.conf stop TenableSC:* ')
                run('/usr/bin/rpm -Uvh --nodeps $(repoquery --location SecurityCenter)')
                run('/usr/bin/pkill -9 httpd; /usr/bin/pkill -9 php')

        if stype == 'all':
            stype = 'full'
        # First we need to shutdown the appropriate components...
        if stype in ['full', 'repos', 'sc']:
            print('Stopping Tenable.sc to prepare for data merge...   ')
            run('/usr/bin/supervisorctl -c /etc/supervisord-tenablesc.conf stop TenableSC:* ')

        # Next we will start pulling the appropriate pakcages and overlaying
        # them on top of the existing system.
        if stype in ['full', 'repos', 'sc']:
            self.overlay('sc-repos')
        if stype in ['full', 'sc']:
            self.overlay('sc-data')
            # empty directories are ignored with the bundler process, further
            # SC doesn't create directories on demand, so we will need to create
            # these back out.
            run('mkdir -p /opt/sc/orgs/1/uploads')
            users = os.listdir('/opt/sc/orgs/1/users')
            run('mkdir -p /opt/sc/orgs/1/logs')
            run('mkdir -p /opt/sc/orgs/1/tmp')
            run('mkdir -p /opt/sc/orgs/1/users/{%s}/reports' % ','.join(users))
            run('mkdir -p /opt/sc/orgs/1/users/{%s}/dashboards' % ','.join(users))


        # Lets pass this off to the localization function ;)
        sleep(5)
        self.do_boxify(stype)

        print('Synchronization Complete.')


    def do_boxify(self, sync_type):
        '''
        Strips away the external linkages that Tenable.sc may have so that it may
        be usable as a detached image.
        '''

        # if nothing was specified for the Sync type, then we will assume that the default
        # is a full localization.
        if sync_type == '':
            sync_type = 'full'

        # No matter what we do, we will always want to change the ownership of SecurityCenter
        # to the tns user and tns group.
        print('Reverting ownership to whats expected...')
        run('/usr/bin/chown -R tns:tns /opt/sc')

        # If the repositories were the only thing that was synced, then all we need to do
        # is start SecurityCenter back up...
        if sync_type in ['repos', 'sc', 'full']:
            print('Restarting Tenable.sc services ...   ')
            run('/usr/sbin/setcap CAP_NET_BIND_SERVICE=+eip /opt/sc/support/bin/httpd')
            run('/usr/bin/supervisorctl -c /etc/supervisord-tenablesc.conf stop TenableSC:*')
            run('/usr/bin/supervisorctl -c /etc/supervisord-tenablesc.conf start TenableSC:*')
            sleep(10)

        # If we synced over the SecurityCenter data en-masse, then we will want to localize
        # the installation so that it won't fail all over the place.  That would be messy ;)
        if sync_type in ['full', 'sc']:

            # We need to reset all the passwords in the system to "password"
            # to allow full access to all of the users that are in SecurityCenter.
            # we will may need to attempt to run the command multiple times if
            # the database is locked, so lets check to see if any errors come back
            # and rerun the command if thats the case.
            print('Overriding user passwords [setting to "password"]...')
            complete = False
            while not complete:
                # Reset the password to "password" and unlock all accounts.
                r = run(' '.join([
                    'sqlite3 /opt/sc/application.db',
                    '"update userauth',
                    'set password = \'943807ff8e7f4735e2a4774f0cf9ceec1044889088737759ef1f329beb40de00107446dffa66fdcc3d557c1b5109800b8f5083cd4e6cd018c5739135f9ceeb12\',', 
                            'salt = \'e+xmTMivzO0Jmyl3XLcDIKcnXOWaKYzWCRRJu2ebr41K8sHJjtYy7JGJwR3IfohbFLUHWzVlivXtt8Dn/ok2tg==\','
                                'locked = \'false\',', 'hashtype = \'2\'', 'where parentID is \'-1\';"',
                ]))
                if 'Error' in r:
                    print('\t- Database is locked, retrying...')
                    sleep(1)
                else:
                    complete = True

            # Ensuring the license is properly set:
            print("Validating proper license...")
            license = open("/labbox/license.key", "rb")
            sc = TenableSC('localhost', username="admin", password="password")
            sc_lic_path = sc.files.upload(license)
            lic_post = sc.post('/config/license/register', json={"filename": sc_lic_path })

            # We need to remove the existing scanners, sensors, and LCEs in
            # order to avoid slowdowns with SC trying to communicate to these
            # devices and to stop erroneous scans is the user happens to be
            # on the VPN.  We will leave the scan schedules as is so that
            # these can be presented during demos.
            print('Deleting links to existing Scanners, PVS Sensors, and LCEs...')
            sc = TenableSC('127.0.0.1', username="admin", password="password")

            for scanner in sc.get('scanner').json()['response']:
                sc.delete('scanner/%s' % scanner['id'])
            for sensor in sc.get('passivescanner').json()['response']:
                sc.delete('passivescanner/%s' % sensor['id'])
            for lce in sc.get('lce').json()['response']:
                sc.delete('lce/%s' % lce['id'])
            #for indusec in sc.get('industrialSecurity').json()['response']:
                #sc.delete('industrialSecurity/{}'.format(indusec['id']))

            # Override the PVS data expiration settings to make sure the
            # data doesn't expire on us.
            print('Setting passive data expiration to 365 days...')
            sc.patch('configSection/5', json={'PassiveVulnsLifetime': 365})

            # Lets login as the orghead account
            orghead = TenableSC('127.0.0.1', username="admin", password="password")

            # Time to allow all users to "Manage Objects" as it seems to
            # be the only way to get shared dashboards working correctly.
            print('Allowing users to manage objects (workaround to dashboard issues)...')
            users = orghead.get('user').json()['response']
            for user in users:
                try:
                    if user['authType'] != 'linked':
                        print('\t- Allowing %s to manage all objects.' % user['username'])
                        orghead.patch('user/%s' % user['id'], json={'managedObjectsGroups': [{'id': -1}]})
                except:
                    pass

    def do_gapfill(self, s):
        '''
        GapFill is designed to fill in the gaps in Tenable.sc repositories
        that may exist if the Tenable.sc services were off-line at the time
        that the snapshots are supposed to be taken.  As a result, those days
        will report as nothing and will cause drops in the trending.  Here we
        will attempt to correct that, however you will still need to edit and
        submit any components that have already expressed this gap.
        '''

        def snapdate(date, ahead):
            return (date + datetime.timedelta(days=ahead)).strftime('%Y-%m-%d')

        def gen_snapdate(snap, rid, days):
            return '/opt/sc/repositories/%s/VDB/%s' % (rid, snapdate(snap, days))

        reporex = re.compile(r'/opt/sc/repositories/(\d{1,3})/VDB/(.*)')

        gapfill_done=0
        count = 1
        today = datetime.date.today()
        while count > 0:
            count = 0
            for item in os.walk('/opt/sc/repositories'):
                try:
                    rid, snap = reporex.findall(item[0])[0]
                    year, month, day = snap.split('-')
                    snap = datetime.date(int(year), int(month), int(day))
                    rid = int(rid)
                except:
                    continue
                else:
                    if not os.path.exists(gen_snapdate(snap, rid, 1)):
                        if (snap + datetime.timedelta(days=1)) < today:
                            count += 1
                            shutil.copytree(gen_snapdate(snap, rid, 0),
                                            gen_snapdate(snap, rid, 1))
                            print('[Repo %s] Creating Snap for %s using %s' %\
                                  (rid, snapdate(snap, 1), snapdate(snap, 0)))
                            gapfill_done=1
        
        if gapfill_done == 1:
    
            # Run Boxify to ensure permissions are correct on new snaps
            self.do_boxify("repos")
            
            # Refresh all dashboards that are line or area charts and may need to be updated.
            sc = TenableSC('localhost', username="secmanager", password="password")
            
            # Get the list of dashboards and components.  Pull out the useful bits.
            dashboard_resp = sc.get('dashboard?fields=id,dashboardComponents')
            dashboard_resp_parsed = json.loads(dashboard_resp.text)
            dashboard_resp_parsed = dashboard_resp_parsed["response"]["usable"]

            # Loop over each dashboard by ID
            for d_id in dashboard_resp_parsed:
                components = d_id['dashboardComponents']
                dashboard_id = d_id.get("id", "")
                # Loop over each dashboard component by ID
                for dcs in components:
                    component_id = dcs.get("id", "")
                    # Request the current dashboard status and type
                    component_type = sc.get('dashboard/' + dashboard_id + '/component/' + component_id + '?fields=componentType,name,definition')
                    component_resp = json.loads(component_type.text)
                    # Find all the line and area chart components; ignore the rest
                    if component_resp['response']['componentType'] == "lineChart" or component_resp['response']['componentType'] == "areaChart": 
                        print("Updating dashboard: " + component_resp['response']['name'] + " (" + component_resp['response']['componentType'] + ")")
                        # Submit an HTTP PATCH to the dashboard using the definition we just grabbed to 'edit' the dashboard to refresh it.
                        sc.patch('dashboard/' + dashboard_id + '/component/' + component_id, data=json.dumps(component_resp['response']))

    def do_feed_update(self, stype):
        '''
        Feed-update will process online feed updates for tenable.sc.  The feed 
        type must be specified as part of the command.

        active           Update the active plugin feed.
        passive          Update the passive plugin feed.
        lce              Update the lce plugin feed.
        sc               Update the tenable.sc feed (VPR, Dashboards, etc).
        '''

        # if the user didnt specify anything, then we should inform them of the
        # options that they can use and bail.
        if stype == '' or stype not in ['active', 'sc', 'passive', 'lce']:
            self.do_help('feed_update')
            return

        if run('/usr/bin/rpm -qa SecurityCenter') == '':
            sys.exit('!!! Tenable.sc not installed.  Aborting feed update...           !!!')
        
        # Request an update
        sc = TenableSC('localhost', username="admin", password="password")
        sc.feeds.update(stype)

        print('Feed update request for ' + stype + ' complete. This will take several miinutes to download and apply.')

    def do_license_update(self, lic_path):
        '''
        Applies a new license file to Tenable.sc
        '''
        license = open("/labbox/license.key", "r")
        sc = TenableSC('localhost', username="admin", password="password")
        sc_lic_path = sc.files.upload(license)
        lic_post = sc.post('/config/license/register', json={"filename": sc_lic_path })

    def do_config_update(self, stype):
        '''
        Tries to grab a new config file to process
        
        tsc      configurations for t.sc
        '''
        if stype == 'tsc':
            # download t.sc config json
            self.overlay('tsc-config')

            #load the json into a usable dictionary
            new_config = {}
            for filename in os.listdir('/labbox/config/'):
                with open(os.path.join('/labbox/config/', filename), 'r') as f:
                    if filename.endswith('.json'):
                        new_config[filename] = json.load(f)

            #enforce the t.sc feed/nessus activation code from upstream
            print("Applying configuration updates...")
            update_tsc_code = "/opt/sc/support/bin/sqlite3 /opt/sc/application.db " \
                + "\"update Configuration set value = \'" + new_config[filename]['license']['code'] \
                    + "\' where name is \'PluginActivationCode\';\""
            update_tsc_status = "/opt/sc/support/bin/sqlite3 /opt/sc/application.db " \
                + "\"update Configuration set value = \'" + new_config[filename]['license']['status'] \
                    + "\' where name is \'PluginSubscriptionStatus\';\""
            update_tsc_login = "/opt/sc/support/bin/sqlite3 /opt/sc/application.db " \
                + "\"update Configuration set value = \'" + new_config[filename]['license']['login'] \
                    + "\' where name is \'PluginSubscriptionLogin\';\""
            update_tsc_pw = "/opt/sc/support/bin/sqlite3 /opt/sc/application.db " \
                + "\"update Configuration set value = \'" + new_config[filename]['license']['pw'] \
                    + "\' where name is \'PluginSubscriptionPassword\';\""
            run(update_tsc_code)
            run(update_tsc_status)
            run(update_tsc_login)
            run(update_tsc_pw)
            sleep(5)

            self.do_feed_update('active')
            self.do_feed_update('sc')


if __name__ == '__main__':
    if len(sys.argv) > 1:
        CommandLine().onecmd(' '.join(sys.argv[1:]))
    else:
        CommandLine().onecmd('help')
