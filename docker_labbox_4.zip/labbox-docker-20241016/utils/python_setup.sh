#!/usr/bin/bash

/usr/bin/pip3 install --upgrade pip;
/usr/bin/pip3 install --user --upgrade setuptools;
/usr/bin/pip3 install --ignore-installed --user bpython requests beautifulsoup4 python-gnupg sqlalchemy pytenable
