#!/usr/bin/bash

DATE=$(/usr/bin/cat /.build_date)
RUNDATE=$(/usr/bin/date)

/usr/bin/echo ""
/usr/bin/echo "----------------------------"
/usr/bin/echo "Labbox (Tenable.sc) Starting"
/usr/bin/echo "----------------------------"
/usr/bin/echo "Image v2.0 built on $DATE"
/usr/bin/echo "Container started on $RUNDATE"
/usr/bin/echo "----------------------------"

# Update files inside Labbox
/usr/bin/chmod +x /labbox/update.sh
/usr/bin/bash /labbox/update.sh

# Now that we've checked for updates to files, let's actually run T.sc and process any commands passed into the container
/usr/bin/chmod +x /running.sh
/usr/bin/bash /running.sh
